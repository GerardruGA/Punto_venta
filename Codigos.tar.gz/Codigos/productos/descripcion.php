<!DOCTYPE html>
<html lang="es-MX">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Descripción del Producto</title>
    <style>
        /* Estilos CSS */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .producto-atributo {
            margin-bottom: 10px;
        }
        .producto-atributo label {
            font-weight: bold;
        }
        .producto img {
            max-width: 50%; /* Ajusta el ancho al 50% del contenedor */
            width: 100%; /* Asegura que la imagen responda al tamaño del contenedor */
            height: auto; /* Mantener la proporción de la imagen */
            max-height: 400px; /* Limita la altura máxima para que no sea demasiado grande */
            display: block; /* Para centrar la imagen */
            margin: 0 auto; /* Centra la imagen */
        }
        .btn-agregar {
            background-color: #4CAF50; /* Verde */
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Descripción del Producto</h1>

    <?php
    // Verificar si se ha proporcionado un ID del producto en la URL
    if (isset($_GET['id'])) {
        // Conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "TEXCOCO226";
        $dbname = "SAPPORO";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar la conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Obtener el ID del producto de la URL
        $id_producto = $_GET['id'];
        

        $sql = "SELECT * FROM dashboard_producto WHERE id = $id_producto ";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo '<div class="producto">';
            echo '<img src="photo/' . $row["imagen"] . '" alt="' . $row["Tipo_Nombre"] . '">';
            echo '</div>';
            echo '<p><strong>Precio:</strong> $' . $row["Precio"] . '</p>';
            echo '<p><strong>Existencias:</strong> ' . $row["Existencias"] . '</p>';
            echo '<p><strong>Descripción:</strong> ' . $row["descripcion"] . '</p>';
        } else {
            echo "Producto no encontrado.";
        }

        // Consulta SQL para obtener los atributos del producto
        $sql = "SELECT * FROM dashboard_descripcion WHERE id_producto_id = $id_producto";
        $result = $conn->query($sql);

        // Mostrar los atributos del producto
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            echo '<div class="producto-atributo">';
            echo '<label>Corte:</label> ' . $row["Corte"];
            echo '</div>';
            echo '<div class="producto-atributo">';
            echo '<label>Codigo:</label> ' . $row["id_producto_id"];
            echo '</div>';
            echo '<div class="producto-atributo">';
            echo '<label>Forro:</label> ' . $row["Forro"];
            echo '</div>';
            echo '<div class="producto-atributo">';
            echo '<label>Plantilla:</label> ' . $row["Plantilla"];
            echo '</div>';
            echo '<div class="producto-atributo">';
            echo '<label>Suela:</label> ' . $row["Suela"];
            echo '</div>';
            echo "<p><a href='carrito_compra.php?id=" . $row['id_producto_id'] . "' class='btn-agregar'>Agregar al carrito</a></p>";
        } else {
            echo "No se encontraron atributos para este producto.";
        }

        // Cerrar la conexión
        $conn->close();
    } else {
        echo "ID de producto no especificado.";
    }
    ?>
</body>
</html>
