from django.contrib import admin

from import_export import resources
from django.utils.html import format_html
from import_export.admin import ImportExportModelAdmin

from tabnanny import verbose
from django.contrib import admin


admin.site.site_header = "SAPPORO TEXCOCO"
admin.site.site_title = "Administracion de Productos"
admin.site.index_title = "Marcas y Pedidos"


# Register your models here.
from dashboard.models import Temporada
from dashboard.models import Mercado
from dashboard.models import Marca
from dashboard.models import Colores
from dashboard.models import Producto
from dashboard.models import Lista_precio
from dashboard.models import Descripcion
from dashboard.models import Vendedore
from dashboard.models import Pedido
from dashboard.models import pedido_producto


class DescripcioneResources(resources.ModelResource):

    fields=(
        'id_descripcion',
        'Corte',
        'Forro',
        'Plantilla',
        'Suela',
        'id_producto'
           )

    class Meta:
        model = Descripcion

class DescripcionAdmin(ImportExportModelAdmin):
    resource_class = DescripcioneResources

    list_display=("id_descripcion","id_producto","Corte","Forro","Plantilla","Suela")
    search_fields = ['id_producto',] 
    
class Lista_precioResources(resources.ModelResource):

    fields=(
        'id_listaprecio',
        'precio_volumen',
        'precio_ecommerce',
        'id_producto',
        "Fecha_registro"
        )
    
    class Meta:
        model=Lista_precio

class Lista_preciosAdmin(ImportExportModelAdmin):
    resource_class = Lista_precioResources

    list_display=("id_listaprecio","id_producto","precio_volumen","precio_ecommerce","Fecha_registro")
    search_fields = ['id_producto'] 
    date_hierarchy=("Fecha_registro")



class pedido_productoResurces(resources.ModelResource):
    fields=(
        'id_pedido_producto',
        'clave_pedido',
        'clave_Producto'
    
    )
    class Meta:
        model=pedido_producto

class pedido_productoAdmin(ImportExportModelAdmin):
    resources_class = pedido_productoResurces
    list_display=("id_pedido_producto","clave_pedido","clave_Producto")


class ProductoResources(resources.ModelResource):

    fields=(
        'id',
        'Temporada',
        'Mercado',
        'Marca',
        'Color',
        'Tipo_Nombre',
        'Corrida'
        'Existencias',
        'Fecha_registro',
        'imagen',
        'Precio'
        )

    def foto(self, obj):
       return format_html('<img src={} width="130" height="100" />', obj.imagen.url )
        

    class Meta:
        model = Producto


class ProductosAdmin(ImportExportModelAdmin):
    resource_class = ProductoResources

    list_display=("id","Tipo_Nombre","Temporada","Mercado","Marca","Color","Precio","Corrida","Existencias","Fecha_registro","imagen")
    search_fields = ['id',"Tipo_Nombre"] 
    list_filter=("Marca","Temporada",)
    date_hierarchy=("Fecha_registro")


class VendedoreResources(resources.ModelResource):

     fields=(

        'Nombre',
        'Apellido_pa',
        'Apellido_Ma',
        'Edad',
        'Direccion',
        'Telefono',
        'Usuario',
        'Passsword'
        )
     class Meta:
         model = Vendedore
      
    

class VendedoreAdmin(ImportExportModelAdmin):
    resource_class = VendedoreResources

    list_display=("Nombre","Apellido_pa","Apellido_Ma","Edad","Direccion","Telefono","Usuario","Passsword")
    search_fields = ['Nombre',"Usuario"] 
   


class PedidoResources(resources.ModelResource):

     fields=(

        'id_pedido',
        'id_vendedor',
        'Fecha_pedido',
        'Total'
    
        )
     class Meta:
         model = Pedido
      
    

class PedidoAdmin(ImportExportModelAdmin):
    resource_class = PedidoResources

    list_display=("id_pedido","id_vendedor","Fecha_pedido","Total")
    search_fields = ['id_pedido',"id_vendedor"] 
    date_hierarchy=("Fecha_pedido")




admin.site.register(Temporada)
admin.site.register(Mercado)
admin.site.register(Marca)
admin.site.register(Colores)
admin.site.register(Producto,ProductosAdmin)
admin.site.register(Lista_precio,Lista_preciosAdmin)
admin.site.register(Descripcion,DescripcionAdmin)
admin.site.register(Vendedore,VendedoreAdmin)
admin.site.register(Pedido,PedidoAdmin)
admin.site.register(pedido_producto,pedido_productoAdmin)