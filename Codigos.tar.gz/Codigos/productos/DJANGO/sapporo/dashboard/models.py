from typing import Any
from django.db import models


class Temporada(models.Model):
    Clave_Temporada=models.CharField(max_length=30,primary_key=True,verbose_name="Temporada :")

    def __str__(self) :
        return self.Clave_Temporada

class Mercado(models.Model):
    Clave_Mercado=models.CharField(max_length=30,primary_key=True,verbose_name="Mercado :")

    def __str__(self) :
        return self.Clave_Mercado


class Marca(models.Model):
    Clave_marca=models.CharField(max_length=30,primary_key = True,verbose_name ="Marca:")
    def __str__(self):
        return self.Clave_marca

class Colores(models.Model):
    Color =models.CharField(max_length=12,primary_key= True,verbose_name="Color :")
    def __str__(self):
        return self.Color
    


class Producto(models.Model):
    Temporada=models.ForeignKey(Temporada,on_delete=models.CASCADE,verbose_name ="Temporada :")
    Mercado = models.ForeignKey(Mercado,on_delete=models.CASCADE,verbose_name="Mercado :")
    Marca=models.ForeignKey(Marca,on_delete=models.CASCADE,verbose_name="Marca:")
    Color=models.ForeignKey(Colores,on_delete=models.CASCADE,verbose_name="Color :")
    Precio=models.DecimalField(max_digits=8, decimal_places=2,verbose_name="Precio de venta :")
    Tipo_Nombre=models.CharField(max_length =30,verbose_name="Tipo Nombre:")
    Corrida=models.CharField(max_length=20,verbose_name="Tallas:")
    Existencias=models.IntegerField(verbose_name="stock:")
    imagen=models.ImageField('Foto',upload_to="fotos")
    Fecha_registro=models.DateField(auto_now_add =True)
    id=models.BigIntegerField(primary_key=True,verbose_name="Codigo de barras:")
    
    def __int__(self):
        return self.id
    
    


class Lista_precio(models.Model):
    id_listaprecio=models.AutoField(primary_key=True)
    precio_volumen=models.DecimalField(max_digits=8, decimal_places=2,verbose_name="Precio por volumen :")
    precio_ecommerce=models.DecimalField(max_digits=8, decimal_places=2,verbose_name="Precio Ecommerce :")
    id_producto=models.OneToOneField(Producto, verbose_name="Clave Producto :", on_delete=models.CASCADE)
    Fecha_registro=models.DateField(auto_now_add =True)

    def __int__(self):
        return self.id_listaprecio
    
class Descripcion(models.Model):
    
    id_descripcion=models.AutoField(primary_key =True)
    Corte = models.CharField(max_length=30,verbose_name ="Corte :")
    Forro =models.CharField(max_length=30,verbose_name="Forro:")
    Plantilla = models.CharField(max_length=30,verbose_name="Plantilla :")
    Suela=models.CharField(max_length=20,verbose_name="Suela:")
    id_producto=models.OneToOneField(Producto,verbose_name="Clave_Producto:",on_delete=models.CASCADE)

    def __int__(self):
        return self.id_descripcion

    
class Vendedore(models.Model):
    Nombre=models.CharField(max_length=20,verbose_name="Nombre :")
    Apellido_pa=models.CharField(max_length=20,verbose_name="Apellido Paterno:")
    Apellido_Ma=models.CharField(max_length=20,verbose_name="Apellido Materno:")
    Edad = models.PositiveSmallIntegerField(verbose_name="Edad :")
    Direccion = models.CharField(max_length=40,verbose_name="Direccion:")
    Telefono=models.CharField(max_length=12,verbose_name ="Telefono :")
    Usuario=models.CharField(max_length=20,primary_key=True,verbose_name="Usuario :")
    Passsword=models.CharField(max_length=20,verbose_name="Contraseña:")


    def __str__(self):
        return self.Usuario
    
class Pedido(models.Model):
    id_pedido=models.AutoField(primary_key=True)
    id_vendedor=models.ForeignKey(Vendedore,verbose_name="Clave del vendedor",on_delete=models.CASCADE )
    Fecha_pedido=models.DateField(auto_now_add =True)
    Total=models.DecimalField(max_digits=8, decimal_places=2,verbose_name="Total :")    
    def __int__(self):
        return self.id_pedido



class pedido_producto(models.Model):
    id_pedido_producto =models.AutoField(primary_key=True)
    clave_pedido=models.ForeignKey(Pedido,on_delete=models.CASCADE,verbose_name="Numero de pedido:")
    clave_Producto=models.ForeignKey(Producto,verbose_name="Codigo del producto :",on_delete=models.CASCADE)
    
    