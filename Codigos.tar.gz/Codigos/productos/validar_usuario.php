<?php
session_start();

if(isset($_POST['confirmar'])) {
    $usuario = $_POST['usuario'];
    $contraseña = $_POST['contraseña'];

    // Conexión a la base de datos
    $conn = new mysqli("localhost", "root", "TEXCOCO226", "SAPPORO");
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Verificar el usuario y la contraseña
    $sql = "SELECT * FROM dashboard_vendedore WHERE Usuario = '$usuario' AND Passsword = '$contraseña'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Usuario y contraseña válidos
        // Calcular el total de la compra
        $totalCompra = 0;
        foreach($_SESSION['carrito'] as $producto) {
            $totalCompra += $producto['precio'];
        }

        // Insertar en la tabla dashboard_pedido
        $fecha_pedido = date("Y-m-d"); // Obtener la fecha actual
        $id_vendedor = $usuario;

        // Consulta para insertar el registro en la tabla dashboard_pedido
        $sql_insert_pedido = "INSERT INTO dashboard_pedido (Fecha_pedido, Total, id_vendedor_id) VALUES ('$fecha_pedido', '$totalCompra', '$id_vendedor')";
        if ($conn->query($sql_insert_pedido) === TRUE) {
            // Obtener el ID del pedido recién insertado
            $id_pedido = $conn->insert_id;

            // Insertar los productos en la tabla dashboard_pedido_producto
            foreach($_SESSION['carrito'] as $producto) {
                $id_producto = $producto['id'];
                $sql_insert_producto = "INSERT INTO dashboard_pedido_producto (clave_Producto_id, clave_pedido_id) VALUES ('$id_producto', '$id_pedido')";
                if ($conn->query($sql_insert_producto) !== TRUE) {
                    echo "Error al insertar productos en la tabla dashboard_pedido_producto: " . $conn->error;
                    exit(); // Salir del script si hay un error
                }
                
                // Disminuir las existencias del producto en la tabla dashboard_producto
                $sql_update_existencias = "UPDATE dashboard_producto SET Existencias = Existencias - 1 WHERE id = '$id_producto'";
                if ($conn->query($sql_update_existencias) !== TRUE) {
                    echo "Error al actualizar las existencias del producto: " . $conn->error;
                    exit(); // Salir del script si hay un error
                }
            }

            // Limpiar el carrito de compras (eliminar el contenido de la sesión)
            unset($_SESSION['carrito']);

            // Redirigir al archivo index.php
            header("Location: index.php");
            exit();
        } else {
            echo "Error al registrar el pedido: " . $conn->error;
        }
    } else {
        // Usuario o contraseña incorrectos
        echo "¡Usuario o contraseña incorrectos!";
    }

    $conn->close();
} else {
    // Acceso no autorizado
    header("Location: usuario.php");
    exit();
}
?>
