<!DOCTYPE html>
<html lang="es-MX">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo de Productos</title>
    <style>
        /* Estilos CSS  */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .producto {
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 10px;
            padding: 10px;
            width: 300px;
            float: left;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        .btn-agregar {
            background-color: #4CAF50; /* verde*/
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }
        .producto img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>Catálogo de Productos</h1>
    <div class="catalogo">
        <?php
        // Conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "TEXCOCO226";
        $dbname = "SAPPORO";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar la conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Consulta SQL para obtener los datos de la tabla Producto
        $sql = "SELECT * FROM dashboard_producto";
        $result = $conn->query($sql);

        // Mostrar los productos
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo '<div class="producto">';
                echo '<a href="descripcion.php?id=' . $row["id"] . '"><h2>' . $row["Tipo_Nombre"] . '</h2></a>';
                echo '<img src="    photo/' . $row["imagen"] . '" alt="' . $row["Tipo_Nombre"] . '">';
                echo '<p><strong>Precio:</strong> $' . $row["Precio"] . '</p>';
                echo '<p><strong>Existencias:</strong> ' . $row["Existencias"] . '</p>';
                echo '<p><strong>Descripción:</strong> ' . $row["descripcion"] . '</p>';
                echo "<a href='descripcion.php?id=" . $row['id'] . "' class='btn-agregar'>Descripción</a>";
                echo '</div>';
            }
        } else {
            echo "No se encontraron productos.";
        }

        // Cerrar la conexión
        $conn->close();
        ?>
    </div>
</body>
</html>
