<!DOCTYPE html>
<html lang="es-MX">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compra</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Carrito de Compra</h1>
        <?php
        session_start();

        if(isset($_GET['id'])) {
            $producto_id = $_GET['id'];

            // Conexión a la base de datos
            $conn = new mysqli("localhost", "root", "TEXCOCO226", "SAPPORO");
            if ($conn->connect_error) {
                die("Error de conexión: " . $conn->connect_error);
            }

            // Consulta para obtener los detalles del producto
            $sql = "SELECT id, Tipo_Nombre, Precio FROM dashboard_producto WHERE id = $producto_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $id_producto = $row['id'];
                $nombre = $row['Tipo_Nombre'];
                $precio = $row['Precio'];

                // Agregar el producto al carrito (usando un arreglo de sesión)
                if(!isset($_SESSION['carrito'])) {
                    $_SESSION['carrito'] = array();
                }
                array_push($_SESSION['carrito'], array("id" => $id_producto, "nombre" => $nombre, "precio" => $precio));
                echo "<p>$nombre agregado al carrito. Precio: $precio</p>";
            } else {
                echo "Producto no encontrado.";
            }

            $conn->close();
        }

        // Mostrar el contenido del carrito de compras
        echo "<h2>Carrito de Compras</h2>";
        $totalCompra = 0; // Inicializar el total de la compra
        if(isset($_SESSION['carrito']) && count($_SESSION['carrito']) > 0) {
            echo "<ul class='carrito'>";
            foreach($_SESSION['carrito'] as $producto) {
                echo "<li>";
                echo "<span class='nombre'>" . $producto['nombre'] . "</span>";
                echo "<span class='precio'>$" . $producto['precio'] . "</span>";
                echo "</li>";
                $totalCompra += $producto['precio']; // Sumar el precio del producto al total de la compra
            }
            echo "</ul>";
            echo "<p><strong>Total: $" . $totalCompra . "</strong></p>"; // Mostrar el total de la compra
        } else {
            echo "<p class='mensaje-vacio'>El carrito está vacío.</p>";
        }

        // Botón para vaciar el carrito
        echo "<form method='post'>";
        echo "<button type='submit' name='vaciar' class='boton vaciar-btn'>Vaciar Carrito</button>";
        echo "</form>";

        // Vaciar el carrito si se hace clic en el botón
        if(isset($_POST['vaciar'])) {
            unset($_SESSION['carrito']);
            header("Location: index.php"); // Redirigir a la misma página para actualizar el contenido
            exit();
        }

        // Botones para otras acciones
        echo "<a href='usuario.php' class='boton'>Registrar</a>";
        echo "<a href='index.php' class='boton'>Volver al Catálogo</a>";
        ?>
    </div>
</body>
</html>
